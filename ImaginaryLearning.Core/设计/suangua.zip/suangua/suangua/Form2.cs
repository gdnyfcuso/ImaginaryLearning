﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Pythagoras;

namespace suangua
{
    public partial class 玄学研究工具 : Form
    {
        static string guachi = null, yaochi = null;
        public 玄学研究工具()
        {
            InitializeComponent();
            for (int i = 0; i <=23; i++)
            {
                if (i < 10)
                {
                    comboBox1.Items.Add("0"+i);
                }
                else
                {
                    comboBox1.Items.Add(i);    
                }
                

            }
            for (int i = 0; i <=59; i++)
            {
                if (i < 10)
                {
                    comboBox2.Items.Add("0" + i);
                }
                else
                {
                    comboBox2.Items.Add(i);
                }
                
            }
            comboBox1.SelectedIndex = 0;
            comboBox2.SelectedIndex = 0;
        }


        /// <summary>
        /// 通过调用方法生成画像和卦辞
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button1_Click_1(object sender, EventArgs e)
        {
            huagua.NumA = int.Parse(NumA.Text);
            huagua.NumB = int.Parse(NumB.Text);
            int dongyao = 0;
            // string guachi = null,yaochi=null;
            int up = (int.Parse(NumA.Text) - 1) % 8;
            int down = (int.Parse(NumB.Text) - 1) % 8;
            int up1 = 0, up2 = 0, up3 = 0, down1 = 0, down2 = 0, down3 = 0;
            up1 = up;
            up2 = up;
            down1 = down;
            down2 = down;
            up3 = up;
            down3=down;
            pictureBox1.Image = huagua.HuadanGua(up3, 0, 0);
            pictureBox2.Image = huagua.HuadanGua(down3, 0, 0);
            pictureBox3.Image = huagua.GetGuaName(up3, down3, 10.0f, 20.0f);
            huagua.GetGuaChi(up3, down3, out guachi, out yaochi,DateTime.Now,out dongyao,false);
            RTBGuaChi.Text = guachi;
            RTBYaoChi.Text = yaochi;//本卦计算方式
            label32.Text = huagua.GetTiYongWuXing(up3, down3, dongyao);
            huagua.GetBianGuaUpDown(ref up1, ref down1,DateTime.Now,false);
            pictureBox9.Image = huagua.HuadanGua(up1 % 8, 0, 0);
            pictureBox8.Image = huagua.HuadanGua(down1 % 8, 0, 0);
            pictureBox7.Image = huagua.GetGuaName(up1, down1, 10.0f, 20.0f);
            huagua.GetGuaChi(up1, down1, out guachi, out yaochi,DateTime.Now,out dongyao,false);
            RTBBGGC.Text = guachi;
            RTBBGYC.Text = yaochi;//变卦计算方式
            label33.Text = huagua.GetTiYongWuXing(up1, down1, dongyao);
            huagua.GetHuGuaUpDown(ref up2, ref down2);
            pictureBox6.Image = huagua.HuadanGua(up2 % 8, 0, 0);
            pictureBox5.Image = huagua.HuadanGua(down2 % 8, 0, 0);
            pictureBox4.Image = huagua.GetGuaName(up2, down2, 10.0f, 20.0f);
            huagua.GetGuaChi(up2, down2, out guachi, out yaochi,DateTime.Now,out dongyao,false);
            RTBHGGC.Text = guachi;
            RTBHGYC.Text = yaochi;//互卦计算方式
            label34.Text = huagua.GetTiYongWuXing(up2, down2, dongyao);
            //综卦计算方式



        }

        private void button2_Click(object sender, EventArgs e)
        {
           // string guachi = null, yaochi = null;
            huagua.NumA = int.Parse(TBNumA.Text);
            huagua.NumB = int.Parse(TBNumB.Text);
            int dongyao = 0;
            int up = (int.Parse(TBNumA.Text) - 1) % 8;
            int down = (int.Parse(TBNumB.Text) - 1) % 8;
            int benGuaUp = up, bianGuaUp = up, cuoGuaUp = up, zongGuaUp = up, huGuaUp = up, benGuaDown = down, bianGuaDown = down, cuoGuaDown = down, zongGuaDown = down, huGuaDown = down;
            PBBenGuaS.Image = huagua.HuadanGua(benGuaUp, 0, 0);
            PBBenGuaX.Image = huagua.HuadanGua(benGuaDown, 0, 0);
            PBBenGuaName.Image = huagua.GetGuaName(benGuaUp, benGuaDown, 10.0f, 20.0f);//生成本卦
            huagua.GetGuaChi(benGuaUp, benGuaDown, out guachi, out yaochi,DateTime.Now,out dongyao,false);
            benguaguachi.Text = guachi;
            huagua.GetBianGuaUpDown(ref bianGuaUp, ref bianGuaDown,DateTime.Now,false);
            bianguasyao.Image = huagua.HuadanGua(bianGuaUp % 8, 0, 0);
            bianguaxyao.Image = huagua.HuadanGua(bianGuaDown % 8, 0, 0);
            bianguaPBname.Image = huagua.GetGuaName(bianGuaUp, bianGuaDown, 10.0f, 20.0f);//生成变卦
            huagua.GetGuaChi(bianGuaUp, bianGuaDown, out guachi, out yaochi,DateTime.Now,out dongyao,false);
            bianguaguachi.Text = guachi;
            huagua.GetHuGuaUpDown(ref huGuaUp, ref huGuaDown);
            PBHuGuaS.Image = huagua.HuadanGua(huGuaUp % 8, 0, 0);
            PBHuGuaX.Image = huagua.HuadanGua(huGuaDown % 8, 0, 0);
            PBHuGuaName.Image = huagua.GetGuaName(huGuaUp, huGuaDown, 10.0f, 20.0f);//生成互卦
            huagua.GetGuaChi(huGuaUp, huGuaDown, out guachi, out yaochi,DateTime.Now,out dongyao,false);
            huguaguachi.Text = guachi;
            huagua.GetZongGua(ref zongGuaUp, ref zongGuaDown);
            PBZongGuaS.Image = huagua.HuadanGua(zongGuaUp % 8, 0, 0);
            PBZongGuaX.Image = huagua.HuadanGua(zongGuaDown % 8, 0, 0);
            PBZongGuaName.Image = huagua.GetGuaName(zongGuaUp, zongGuaDown, 10.0f, 20.0f);//生成综卦
            huagua.GetGuaChi(zongGuaUp, zongGuaDown, out guachi, out yaochi,DateTime.Now,out dongyao,false);
            zongguaguachi.Text = guachi;
            huagua.GetCuoGua(ref cuoGuaUp, ref cuoGuaDown);
            PBCuoGuaS.Image = huagua.HuadanGua(cuoGuaUp % 8, 0, 0);
            PBCuoGuaX.Image = huagua.HuadanGua(cuoGuaDown % 8, 0, 0);
            PBCuoGuaName.Image = huagua.GetGuaName(cuoGuaUp, cuoGuaDown, 10.0f, 20.0f);//生成错卦
            huagua.GetGuaChi(cuoGuaUp, cuoGuaDown, out guachi, out yaochi,DateTime.Now,out dongyao,false);
            cuoguaguachi.Text = guachi;
            benguaguachi.Visible = true;
            bianguaguachi.Visible = true;
            huguaguachi.Visible = true;
            zongguaguachi.Visible = true;
            cuoguaguachi.Visible = true;


        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void GetTime_Click(object sender, EventArgs e)
        {

            HuaGuaByTime(DateTime.Now);



        }

        private void HuaGuaByTime(DateTime dt)
        {
            
            int up = 0, down = 0,dongyao=0;
            YaLI.Text = dt.ToLongDateString() +" "+ dt.Hour + "时" + dt.Minute + "分";
            YinLi.Text = YinLiChangeYangLi.GetLunarCalendar(dt);
            YinLiChangeYangLi.GetTimeUpDown(dt,out up, out down);
            //huagua.NumA = up;
            //huagua.NumB = down;
            int timeBenGuaUp = up, timeBianGuaUp = up, timeHuGuaUp = up, timeBenGuaDown = down, TimeBianGuaDown = down, timeHuGuaDown = down;
            TimeBenGuas.Image = huagua.HuadanGua(timeBenGuaUp, 0, 0);
            TimeBenGuax.Image = huagua.HuadanGua(timeBenGuaDown, 0, 0);
            TimeBenGuaName.Image = huagua.GetGuaName(timeBenGuaUp, timeBenGuaDown, 10.0f, 20.0f);
            //string guachi = null, yaochi = null;
            huagua.GetGuaChi(timeBenGuaUp, timeBenGuaDown, out guachi, out  yaochi,dt,out dongyao, true);
            TimeBenGuaChi.Text = guachi;
            TimeBenGuaYao.Text = yaochi;//根据时间获得本卦
            label35.Text = huagua.GetTiYongWuXing(timeBenGuaUp, timeBenGuaDown, dongyao);




            huagua.GetHuGuaUpDown(ref timeHuGuaUp, ref timeHuGuaDown);
            TimeHuGuaS.Image = huagua.HuadanGua(timeHuGuaUp % 8, 0, 0);
            TimeHuGuax.Image = huagua.HuadanGua(timeHuGuaDown % 8, 0, 0);
            TimeHuGuaName.Image = huagua.GetGuaName(timeHuGuaUp, timeHuGuaDown, 10.0f, 20.0f);
            huagua.GetGuaChi(timeHuGuaUp, timeHuGuaDown, out guachi, out yaochi,dt,out dongyao, true);
            TimeHuGuaChi.Text = guachi;
            TimeHuGuaYao.Text = yaochi;//根据变化得互卦
            label36.Text = huagua.GetTiYongWuXing(timeHuGuaUp, timeHuGuaDown, dongyao);


            huagua.GetBianGuaUpDown(ref timeBianGuaUp, ref TimeBianGuaDown,dt, true);
            TimeBianGuas.Image = huagua.HuadanGua(timeBianGuaUp % 8, 0, 0);
            TimeBianGuax.Image = huagua.HuadanGua(TimeBianGuaDown % 8, 0, 0);
            TimeBianGuaName.Image = huagua.GetGuaName(timeBianGuaUp, TimeBianGuaDown, 10.0f, 20.0f);
            huagua.GetGuaChi(timeBianGuaUp, TimeBianGuaDown, out guachi, out yaochi,dt,out dongyao, true);
            TimeBianGuaCHi.Text = guachi;
            TimeBianGuaYao.Text = yaochi;//根据变化得变卦
            label37.Text = huagua.GetTiYongWuXing(timeBianGuaUp, TimeBianGuaDown, dongyao);

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox13_Click(object sender, EventArgs e)
        {

        }

        private void TPtime_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
           
            DateTime temptime =DateTime.Parse(dateTimePicker1.Value.Year.ToString() +"-"+ dateTimePicker1.Value.Month.ToString() +"-"+
                              dateTimePicker1.Value.Day.ToString()+" "+comboBox1.SelectedIndex+":"+comboBox2.SelectedIndex+":"+"00");
            HuaGuaByTime(temptime);
           
        }

        private void button4_Click(object sender, EventArgs e)
        {
            //获得传入的时间
            DateTime temptime = DateTime.Parse(dateTimePicker2.Value.Year.ToString() + "-" + dateTimePicker2.Value.Month.ToString() + "-" +
                              dateTimePicker2.Value.Day.ToString() + " " + comboBox2.SelectedIndex + ":" + comboBox2.SelectedIndex + ":" + "00");
            //创建一个数据对象
            PythagorasData pythagorasData=new PythagorasData(temptime);
            //初始化接口下的实例
            IPythagoras  common=new Common(pythagorasData.Common);
            //获得普通的数据
            textBox1.Text ="----------------------------------基本特征------------------------\r\n"+ common.GetResult();
            //初始化天赋数对象
            common=new Talent(pythagorasData.Talent);
            //获得天赋数数据
            textBox1.Text += "---------------------------------天赋特征-------------------------\r\n" + common.GetResult();
            //初始化生命数对象
            common=new Vitality(pythagorasData.Vitality);
            //获得生命数数据
            textBox1.Text += "---------------------------------生命特征--------------------------\r\n" + common.GetResult();
            common=new Synthesize(pythagorasData.MyList);
            textBox1.Text += "---------------------------------综合特征---------------------------\r\n" + common.GetResult();

            //初始化综合对象



        }
    }
}


    

