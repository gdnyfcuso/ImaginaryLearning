﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Rank;

namespace Pythagoras
{
    public class PythagorasData
    {
        private Dictionary<int, int> common;
        private Dictionary<int, int> talent;
        private Dictionary<int, int> vitality;
        private Dictionary<int, int> synthesize;
        public Dictionary<int, int> Common
        {
            get { return common; }
        }
        public Dictionary<int, int> Talent
        {
            get { return talent; }
        }
        public Dictionary<int, int> Vitality
        {
            get { return vitality; }
        }
        public Dictionary<int, int> Synthesize
        {
            get { return synthesize; }
        }
        public List<string> MyList
        {
            get
            {
                List<int> tempArray = Synthesize.Keys.ToList();
                List<int> tempList=new List<int>();

                foreach (var i in tempArray)
                {
                    if ( i!= 0)
                    {
                        tempList.Add(i);
                    }
                }
                return GetListResult(tempList.ToArray());
            }
        }

        private List<string> GetListResult(int[] toArray)
        {
            List<string> mylist = new List<string>();
           
            return GetStringList(GetThreeByToaary(toArray,3),GetThreeByToaary(toArray, 2));


        }

        #region 将得到的集合排列组合起来
        private List<string> GetThreeByToaary(int[] toArray, int flag)
        {
            List<string> myList = new List<string>();
            if (flag == 3)
            {
                for (int i = 0; i < toArray.Length - 2; i++)
                {
                    for (int j = i + 1; j < toArray.Length - 1; j++)
                    {
                        for (int k = j + 1; k < toArray.Length; k++)
                        {
                            myList.Add(toArray[i].ToString() + toArray[j].ToString() + toArray[k].ToString());

                        }
                    }
                }

            }
            else
            {
                for (int i = 0; i < toArray.Length - 1; i++)
                {
                    for (int j = i + 1; j < toArray.Length; j++)
                    {
                        myList.Add(toArray[i].ToString() + toArray[j].ToString());
                    }
                }
            }
            return myList;
        }
        
        #endregion
        #region 将综合数合并
        public List<string> GetStringList(List<string> tempOldList, List<string> tempNewList)
        {
            for (int i = 0; i < tempNewList.Count; i++)
            {
                if (!tempOldList.Contains(tempNewList[i]))
                {
                    tempOldList.Add(tempNewList[i]);
                }

            }
            return tempOldList;
        } 
        #endregion
        #region 初始化外部使用到的属性值
        public PythagorasData(DateTime dateTime)
        {
            this.common = GetCommon(dateTime);
            this.talent = GetTalent(dateTime);
            this.vitality = GetVitality();
            this.synthesize = GetSynthesize();
        }
        #endregion
        #region 将时间转化为字符串

        public string ChangeTimeString(DateTime dateTime)
        {
            string[] tempstring = dateTime.ToShortDateString().Split('-');
            string temp = tempstring[0] + tempstring[1] + tempstring[2];
            return temp;

        }
        #endregion
        #region 初始化普通数
        /// <summary>
        /// 初始化普通数
        /// </summary>
        /// <param name="dateTime">依据的时间</param>
        /// <returns></returns>
        private Dictionary<int, int> GetCommon(DateTime dateTime)
        {

            string tempString = ChangeTimeString(dateTime);

            return GetTempDictionary(tempString, 1);

        }


        #endregion
        #region 处理小于十的情况
        private Dictionary<int, int> GetTempDictionary(string tempString, int seed)
        {
            Dictionary<int, int> dictionary = new Dictionary<int, int>();
            for (int i = 0; i < tempString.Length; i++)
            {
                if (dictionary.ContainsKey(Convert.ToInt32(tempString.Substring(i, 1))))
                {

                    dictionary[Convert.ToInt32(tempString.Substring(i, 1))] += seed;
                }
                else
                {
                    dictionary.Add(Convert.ToInt32(tempString.Substring(i, 1)), seed);

                }
            }
            return dictionary;

        }

        #endregion
        #region 处理生命数大于十的情况
        private Dictionary<int, int> GetDaYuShiDictionary( int tempInt)
        {
            Dictionary<int, int> dictionary = new Dictionary<int, int>();
            string tempString = tempInt.ToString();
            int numA = Convert.ToInt32(tempString.Substring(0, 1));
            int numB = Convert.ToInt32(tempString.Substring(1, 1));

            int temp = numA +numB ;

            talent = GetTempTalent(talent, numA);
            talent = GetTempTalent(talent, numB);
           
           
           

           

            dictionary.Add(temp,3);
            return dictionary;



        }

        private Dictionary<int, int> GetTempTalent(Dictionary<int, int> p0, int numA)
        {
            foreach (var i in p0)
            {
                if (p0.ContainsKey(numA))
                {
                    p0[numA] += 2;
                }
                else
                {
                    p0.Add(numA,2);
                }
                break;
                
            }
            return p0;
        }

        #endregion
        #region 初始化天赋数
        /// <summary>
        /// 初始华天赋数
        /// </summary>
        /// <param name="dateTime"></param>
        /// <returns></returns>
        private Dictionary<int, int> GetTalent(DateTime dateTime)
        {

            int tempInt = 0;
            string tempstring = ChangeTimeString(dateTime);
            for (int i = 0; i < tempstring.Length; i++)
            {
                tempInt += Convert.ToInt32(tempstring.Substring(i, 1));
            }
            return GetTempDictionary(tempInt.ToString(), 2);
        }
        #endregion
        #region 初始化生命数

        private Dictionary<int, int> GetVitality()
        {
            Dictionary<int, int> dictionary = new Dictionary<int, int>();
            int tempInt = 0;
            foreach (var i in talent.Keys)
            {
                tempInt += i;
            }
            dictionary = GetTempDictionary(tempInt.ToString(), 3);
            if (tempInt >=10)
            {
                dictionary = GetDaYuShiDictionary(tempInt);
            }

            return dictionary;
        }


        #endregion
        #region 初始化综合数

        private Dictionary<int, int> GetSynthesize()
        {
            Dictionary<int, int> mDictionary = new Dictionary<int, int>();
            mDictionary = AddNumInList(mDictionary, common);
            mDictionary = AddNumInList(mDictionary, talent);
            mDictionary = AddNumInList(mDictionary, vitality);

            return mDictionary;
        }
        #endregion
        #region 将字典里面的数据加到list集合里面去
        private Dictionary<int, int> AddNumInList(Dictionary<int, int> myList, Dictionary<int, int> mydic)
        {

            foreach (var i in mydic.Keys)
            {

                if (myList.ContainsKey(i))
                {
                    //判断新字典里面是否有这个键值,有的话将字典里面的值取出来再写回去
                    myList[i] = myList[i] + mydic[i];

                }
                else
                {
                    //没有的话刚添加进去
                    myList.Add(i, mydic[i]);

                }

            }
            return myList;
        }
        #endregion
    }
}
