﻿namespace suangua
{
    partial class 玄学研究工具
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(玄学研究工具));
            this.tabpageGuaTool = new System.Windows.Forms.TabControl();
            this.TPnum = new System.Windows.Forms.TabPage();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.button1 = new System.Windows.Forms.Button();
            this.Result = new System.Windows.Forms.Panel();
            this.RTBHGYC = new System.Windows.Forms.RichTextBox();
            this.RTBHGGC = new System.Windows.Forms.RichTextBox();
            this.RTBBGYC = new System.Windows.Forms.RichTextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.RTBBGGC = new System.Windows.Forms.RichTextBox();
            this.RTBYaoChi = new System.Windows.Forms.RichTextBox();
            this.RTBGuaChi = new System.Windows.Forms.RichTextBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.NumB = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.NumA = new System.Windows.Forms.TextBox();
            this.TPtime = new System.Windows.Forms.TabPage();
            this.label31 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.button3 = new System.Windows.Forms.Button();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.timeresult = new System.Windows.Forms.Panel();
            this.TimeHuGuaYao = new System.Windows.Forms.RichTextBox();
            this.TimeHuGuaChi = new System.Windows.Forms.RichTextBox();
            this.TimeBianGuaYao = new System.Windows.Forms.RichTextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.TimeBianGuaCHi = new System.Windows.Forms.RichTextBox();
            this.TimeBenGuaYao = new System.Windows.Forms.RichTextBox();
            this.TimeBenGuaChi = new System.Windows.Forms.RichTextBox();
            this.TimeBianGuaName = new System.Windows.Forms.PictureBox();
            this.TimeBianGuax = new System.Windows.Forms.PictureBox();
            this.TimeBianGuas = new System.Windows.Forms.PictureBox();
            this.TimeHuGuaName = new System.Windows.Forms.PictureBox();
            this.TimeHuGuax = new System.Windows.Forms.PictureBox();
            this.TimeHuGuaS = new System.Windows.Forms.PictureBox();
            this.TimeBenGuaName = new System.Windows.Forms.PictureBox();
            this.TimeBenGuax = new System.Windows.Forms.PictureBox();
            this.TimeBenGuas = new System.Windows.Forms.PictureBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.YinLi = new System.Windows.Forms.Label();
            this.YaLI = new System.Windows.Forms.Label();
            this.GetTime = new System.Windows.Forms.Button();
            this.TPRMB = new System.Windows.Forms.TabPage();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.button4 = new System.Windows.Forms.Button();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.GetTool = new System.Windows.Forms.TabPage();
            this.benguaguachi = new System.Windows.Forms.RichTextBox();
            this.bianguaguachi = new System.Windows.Forms.RichTextBox();
            this.huguaguachi = new System.Windows.Forms.RichTextBox();
            this.zongguaguachi = new System.Windows.Forms.RichTextBox();
            this.cuoguaguachi = new System.Windows.Forms.RichTextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.TBNumB = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.TBNumA = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.PBZongGuaName = new System.Windows.Forms.PictureBox();
            this.PBZongGuaX = new System.Windows.Forms.PictureBox();
            this.PBZongGuaS = new System.Windows.Forms.PictureBox();
            this.label15 = new System.Windows.Forms.Label();
            this.PBCuoGuaName = new System.Windows.Forms.PictureBox();
            this.PBCuoGuaX = new System.Windows.Forms.PictureBox();
            this.PBCuoGuaS = new System.Windows.Forms.PictureBox();
            this.label14 = new System.Windows.Forms.Label();
            this.bianguaPBname = new System.Windows.Forms.PictureBox();
            this.bianguaxyao = new System.Windows.Forms.PictureBox();
            this.bianguasyao = new System.Windows.Forms.PictureBox();
            this.label7 = new System.Windows.Forms.Label();
            this.PBHuGuaName = new System.Windows.Forms.PictureBox();
            this.PBHuGuaX = new System.Windows.Forms.PictureBox();
            this.PBHuGuaS = new System.Windows.Forms.PictureBox();
            this.label6 = new System.Windows.Forms.Label();
            this.PBBenGuaName = new System.Windows.Forms.PictureBox();
            this.PBBenGuaX = new System.Windows.Forms.PictureBox();
            this.PBBenGuaS = new System.Windows.Forms.PictureBox();
            this.TPFangTu = new System.Windows.Forms.TabPage();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.tabpageGuaTool.SuspendLayout();
            this.TPnum.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            this.Result.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.TPtime.SuspendLayout();
            this.timeresult.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.TimeBianGuaName)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TimeBianGuax)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TimeBianGuas)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TimeHuGuaName)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TimeHuGuax)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TimeHuGuaS)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TimeBenGuaName)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TimeBenGuax)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TimeBenGuas)).BeginInit();
            this.TPRMB.SuspendLayout();
            this.GetTool.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PBZongGuaName)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBZongGuaX)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBZongGuaS)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBCuoGuaName)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBCuoGuaX)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBCuoGuaS)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bianguaPBname)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bianguaxyao)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bianguasyao)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBHuGuaName)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBHuGuaX)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBHuGuaS)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBBenGuaName)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBBenGuaX)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBBenGuaS)).BeginInit();
            this.SuspendLayout();
            // 
            // tabpageGuaTool
            // 
            this.tabpageGuaTool.Controls.Add(this.TPnum);
            this.tabpageGuaTool.Controls.Add(this.TPtime);
            this.tabpageGuaTool.Controls.Add(this.TPRMB);
            this.tabpageGuaTool.Controls.Add(this.tabPage4);
            this.tabpageGuaTool.Controls.Add(this.tabPage5);
            this.tabpageGuaTool.Controls.Add(this.GetTool);
            this.tabpageGuaTool.Controls.Add(this.TPFangTu);
            this.tabpageGuaTool.ImeMode = System.Windows.Forms.ImeMode.On;
            this.tabpageGuaTool.Location = new System.Drawing.Point(1, -4);
            this.tabpageGuaTool.Multiline = true;
            this.tabpageGuaTool.Name = "tabpageGuaTool";
            this.tabpageGuaTool.SelectedIndex = 0;
            this.tabpageGuaTool.Size = new System.Drawing.Size(1249, 750);
            this.tabpageGuaTool.TabIndex = 0;
            // 
            // TPnum
            // 
            this.TPnum.BackColor = System.Drawing.Color.DimGray;
            this.TPnum.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("TPnum.BackgroundImage")));
            this.TPnum.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.TPnum.Controls.Add(this.pictureBox11);
            this.TPnum.Controls.Add(this.pictureBox10);
            this.TPnum.Controls.Add(this.button1);
            this.TPnum.Controls.Add(this.Result);
            this.TPnum.Controls.Add(this.NumB);
            this.TPnum.Controls.Add(this.label2);
            this.TPnum.Controls.Add(this.label1);
            this.TPnum.Controls.Add(this.NumA);
            this.TPnum.Location = new System.Drawing.Point(4, 22);
            this.TPnum.Name = "TPnum";
            this.TPnum.Padding = new System.Windows.Forms.Padding(3);
            this.TPnum.Size = new System.Drawing.Size(1241, 724);
            this.TPnum.TabIndex = 0;
            this.TPnum.Text = "数字占";
            this.TPnum.UseVisualStyleBackColor = true;
            this.TPnum.Click += new System.EventHandler(this.tabPage1_Click);
            // 
            // pictureBox11
            // 
            this.pictureBox11.Image = global::suangua.Properties.Resources.太极图;
            this.pictureBox11.Location = new System.Drawing.Point(979, 6);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(260, 225);
            this.pictureBox11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox11.TabIndex = 7;
            this.pictureBox11.TabStop = false;
            // 
            // pictureBox10
            // 
            this.pictureBox10.Image = global::suangua.Properties.Resources.八卦图;
            this.pictureBox10.Location = new System.Drawing.Point(9, 6);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(257, 224);
            this.pictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox10.TabIndex = 6;
            this.pictureBox10.TabStop = false;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("宋体", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button1.Location = new System.Drawing.Point(519, 177);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(194, 41);
            this.button1.TabIndex = 5;
            this.button1.Text = "开始占卜";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // Result
            // 
            this.Result.BackColor = System.Drawing.Color.White;
            this.Result.Controls.Add(this.label34);
            this.Result.Controls.Add(this.label33);
            this.Result.Controls.Add(this.label32);
            this.Result.Controls.Add(this.RTBHGYC);
            this.Result.Controls.Add(this.RTBHGGC);
            this.Result.Controls.Add(this.RTBBGYC);
            this.Result.Controls.Add(this.label10);
            this.Result.Controls.Add(this.label9);
            this.Result.Controls.Add(this.label5);
            this.Result.Controls.Add(this.label11);
            this.Result.Controls.Add(this.label12);
            this.Result.Controls.Add(this.label13);
            this.Result.Controls.Add(this.label8);
            this.Result.Controls.Add(this.label4);
            this.Result.Controls.Add(this.label3);
            this.Result.Controls.Add(this.RTBBGGC);
            this.Result.Controls.Add(this.RTBYaoChi);
            this.Result.Controls.Add(this.RTBGuaChi);
            this.Result.Controls.Add(this.pictureBox7);
            this.Result.Controls.Add(this.pictureBox8);
            this.Result.Controls.Add(this.pictureBox9);
            this.Result.Controls.Add(this.pictureBox4);
            this.Result.Controls.Add(this.pictureBox5);
            this.Result.Controls.Add(this.pictureBox6);
            this.Result.Controls.Add(this.pictureBox3);
            this.Result.Controls.Add(this.pictureBox2);
            this.Result.Controls.Add(this.pictureBox1);
            this.Result.Location = new System.Drawing.Point(0, 233);
            this.Result.Name = "Result";
            this.Result.Size = new System.Drawing.Size(1235, 302);
            this.Result.TabIndex = 4;
            // 
            // RTBHGYC
            // 
            this.RTBHGYC.Location = new System.Drawing.Point(841, 109);
            this.RTBHGYC.Name = "RTBHGYC";
            this.RTBHGYC.Size = new System.Drawing.Size(394, 88);
            this.RTBHGYC.TabIndex = 15;
            this.RTBHGYC.Text = "";
            // 
            // RTBHGGC
            // 
            this.RTBHGGC.Location = new System.Drawing.Point(412, 109);
            this.RTBHGGC.Name = "RTBHGGC";
            this.RTBHGGC.Size = new System.Drawing.Size(388, 88);
            this.RTBHGGC.TabIndex = 14;
            this.RTBHGGC.Text = "";
            // 
            // RTBBGYC
            // 
            this.RTBBGYC.Location = new System.Drawing.Point(841, 207);
            this.RTBBGYC.Name = "RTBBGYC";
            this.RTBBGYC.Size = new System.Drawing.Size(394, 85);
            this.RTBBGYC.TabIndex = 13;
            this.RTBBGYC.Text = "";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(7, 210);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(29, 12);
            this.label10.TabIndex = 12;
            this.label10.Text = "变卦";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(7, 15);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(29, 12);
            this.label9.TabIndex = 12;
            this.label9.Text = "本卦";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(350, 210);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(53, 12);
            this.label5.TabIndex = 12;
            this.label5.Text = "变卦卦辞";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(7, 109);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(29, 12);
            this.label11.TabIndex = 12;
            this.label11.Text = "互卦";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(806, 207);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(29, 12);
            this.label12.TabIndex = 12;
            this.label12.Text = "动爻";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(806, 109);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(29, 12);
            this.label13.TabIndex = 12;
            this.label13.Text = "动爻";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(806, 12);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(29, 12);
            this.label8.TabIndex = 12;
            this.label8.Text = "动爻";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(350, 109);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 12);
            this.label4.TabIndex = 12;
            this.label4.Text = "互卦卦辞";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(350, 15);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 12);
            this.label3.TabIndex = 12;
            this.label3.Text = "本卦卦辞";
            // 
            // RTBBGGC
            // 
            this.RTBBGGC.Location = new System.Drawing.Point(412, 207);
            this.RTBBGGC.Name = "RTBBGGC";
            this.RTBBGGC.Size = new System.Drawing.Size(388, 85);
            this.RTBBGGC.TabIndex = 11;
            this.RTBBGGC.Text = "";
            // 
            // RTBYaoChi
            // 
            this.RTBYaoChi.Location = new System.Drawing.Point(841, 13);
            this.RTBYaoChi.Name = "RTBYaoChi";
            this.RTBYaoChi.Size = new System.Drawing.Size(394, 85);
            this.RTBYaoChi.TabIndex = 10;
            this.RTBYaoChi.Text = "";
            // 
            // RTBGuaChi
            // 
            this.RTBGuaChi.Location = new System.Drawing.Point(412, 12);
            this.RTBGuaChi.Name = "RTBGuaChi";
            this.RTBGuaChi.Size = new System.Drawing.Size(388, 85);
            this.RTBGuaChi.TabIndex = 9;
            this.RTBGuaChi.Text = "";
            // 
            // pictureBox7
            // 
            this.pictureBox7.Location = new System.Drawing.Point(241, 207);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(96, 85);
            this.pictureBox7.TabIndex = 8;
            this.pictureBox7.TabStop = false;
            // 
            // pictureBox8
            // 
            this.pictureBox8.Location = new System.Drawing.Point(139, 247);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(96, 42);
            this.pictureBox8.TabIndex = 7;
            this.pictureBox8.TabStop = false;
            // 
            // pictureBox9
            // 
            this.pictureBox9.Location = new System.Drawing.Point(139, 207);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(96, 40);
            this.pictureBox9.TabIndex = 6;
            this.pictureBox9.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Location = new System.Drawing.Point(241, 109);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(96, 85);
            this.pictureBox4.TabIndex = 5;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Location = new System.Drawing.Point(138, 148);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(96, 42);
            this.pictureBox5.TabIndex = 4;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Location = new System.Drawing.Point(138, 109);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(96, 40);
            this.pictureBox6.TabIndex = 3;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Location = new System.Drawing.Point(241, 12);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(96, 85);
            this.pictureBox3.TabIndex = 2;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Location = new System.Drawing.Point(136, 50);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(96, 42);
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(136, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(96, 40);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // NumB
            // 
            this.NumB.Location = new System.Drawing.Point(765, 138);
            this.NumB.Multiline = true;
            this.NumB.Name = "NumB";
            this.NumB.Size = new System.Drawing.Size(121, 33);
            this.NumB.TabIndex = 3;
            this.NumB.Text = "1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("宋体", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.Location = new System.Drawing.Point(656, 136);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(103, 35);
            this.label2.TabIndex = 2;
            this.label2.Text = "数字B";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("宋体", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(333, 138);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(95, 33);
            this.label1.TabIndex = 1;
            this.label1.Text = "数字A";
            // 
            // NumA
            // 
            this.NumA.Location = new System.Drawing.Point(452, 138);
            this.NumA.Multiline = true;
            this.NumA.Name = "NumA";
            this.NumA.Size = new System.Drawing.Size(100, 33);
            this.NumA.TabIndex = 0;
            this.NumA.Text = "1";
            // 
            // TPtime
            // 
            this.TPtime.BackColor = System.Drawing.Color.DimGray;
            this.TPtime.Controls.Add(this.label31);
            this.TPtime.Controls.Add(this.label30);
            this.TPtime.Controls.Add(this.comboBox2);
            this.TPtime.Controls.Add(this.comboBox1);
            this.TPtime.Controls.Add(this.button3);
            this.TPtime.Controls.Add(this.dateTimePicker1);
            this.TPtime.Controls.Add(this.timeresult);
            this.TPtime.Controls.Add(this.label20);
            this.TPtime.Controls.Add(this.label19);
            this.TPtime.Controls.Add(this.YinLi);
            this.TPtime.Controls.Add(this.YaLI);
            this.TPtime.Controls.Add(this.GetTime);
            this.TPtime.Location = new System.Drawing.Point(4, 22);
            this.TPtime.Name = "TPtime";
            this.TPtime.Padding = new System.Windows.Forms.Padding(3);
            this.TPtime.Size = new System.Drawing.Size(1241, 724);
            this.TPtime.TabIndex = 1;
            this.TPtime.Text = "时间占";
            this.TPtime.UseVisualStyleBackColor = true;
            this.TPtime.Click += new System.EventHandler(this.TPtime_Click);
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(1065, 45);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(17, 12);
            this.label31.TabIndex = 11;
            this.label31.Text = "分";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(952, 46);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(17, 12);
            this.label30.TabIndex = 10;
            this.label30.Text = "时";
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(1099, 38);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(53, 20);
            this.comboBox2.TabIndex = 9;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(996, 39);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(53, 20);
            this.comboBox1.TabIndex = 8;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(719, 140);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(135, 23);
            this.button3.TabIndex = 7;
            this.button3.Text = "根据选择时间";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(719, 39);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 21);
            this.dateTimePicker1.TabIndex = 6;
            // 
            // timeresult
            // 
            this.timeresult.BackColor = System.Drawing.Color.White;
            this.timeresult.Controls.Add(this.label37);
            this.timeresult.Controls.Add(this.label36);
            this.timeresult.Controls.Add(this.label35);
            this.timeresult.Controls.Add(this.TimeHuGuaYao);
            this.timeresult.Controls.Add(this.TimeHuGuaChi);
            this.timeresult.Controls.Add(this.TimeBianGuaYao);
            this.timeresult.Controls.Add(this.label21);
            this.timeresult.Controls.Add(this.label22);
            this.timeresult.Controls.Add(this.label23);
            this.timeresult.Controls.Add(this.label24);
            this.timeresult.Controls.Add(this.label25);
            this.timeresult.Controls.Add(this.label26);
            this.timeresult.Controls.Add(this.label27);
            this.timeresult.Controls.Add(this.label28);
            this.timeresult.Controls.Add(this.label29);
            this.timeresult.Controls.Add(this.TimeBianGuaCHi);
            this.timeresult.Controls.Add(this.TimeBenGuaYao);
            this.timeresult.Controls.Add(this.TimeBenGuaChi);
            this.timeresult.Controls.Add(this.TimeBianGuaName);
            this.timeresult.Controls.Add(this.TimeBianGuax);
            this.timeresult.Controls.Add(this.TimeBianGuas);
            this.timeresult.Controls.Add(this.TimeHuGuaName);
            this.timeresult.Controls.Add(this.TimeHuGuax);
            this.timeresult.Controls.Add(this.TimeHuGuaS);
            this.timeresult.Controls.Add(this.TimeBenGuaName);
            this.timeresult.Controls.Add(this.TimeBenGuax);
            this.timeresult.Controls.Add(this.TimeBenGuas);
            this.timeresult.Location = new System.Drawing.Point(3, 211);
            this.timeresult.Name = "timeresult";
            this.timeresult.Size = new System.Drawing.Size(1235, 302);
            this.timeresult.TabIndex = 5;
            this.timeresult.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // TimeHuGuaYao
            // 
            this.TimeHuGuaYao.Location = new System.Drawing.Point(825, 109);
            this.TimeHuGuaYao.Name = "TimeHuGuaYao";
            this.TimeHuGuaYao.Size = new System.Drawing.Size(421, 87);
            this.TimeHuGuaYao.TabIndex = 15;
            this.TimeHuGuaYao.Text = "";
            // 
            // TimeHuGuaChi
            // 
            this.TimeHuGuaChi.Location = new System.Drawing.Point(396, 109);
            this.TimeHuGuaChi.Name = "TimeHuGuaChi";
            this.TimeHuGuaChi.Size = new System.Drawing.Size(384, 88);
            this.TimeHuGuaChi.TabIndex = 14;
            this.TimeHuGuaChi.Text = "";
            // 
            // TimeBianGuaYao
            // 
            this.TimeBianGuaYao.Location = new System.Drawing.Point(825, 207);
            this.TimeBianGuaYao.Name = "TimeBianGuaYao";
            this.TimeBianGuaYao.Size = new System.Drawing.Size(421, 84);
            this.TimeBianGuaYao.TabIndex = 13;
            this.TimeBianGuaYao.Text = "";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(7, 210);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(29, 12);
            this.label21.TabIndex = 12;
            this.label21.Text = "变卦";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(7, 15);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(29, 12);
            this.label22.TabIndex = 12;
            this.label22.Text = "本卦";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(336, 210);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(53, 12);
            this.label23.TabIndex = 12;
            this.label23.Text = "变卦卦辞";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(7, 109);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(29, 12);
            this.label24.TabIndex = 12;
            this.label24.Text = "互卦";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(790, 207);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(29, 12);
            this.label25.TabIndex = 12;
            this.label25.Text = "动爻";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(790, 109);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(29, 12);
            this.label26.TabIndex = 12;
            this.label26.Text = "动爻";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(790, 12);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(29, 12);
            this.label27.TabIndex = 12;
            this.label27.Text = "动爻";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(336, 109);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(53, 12);
            this.label28.TabIndex = 12;
            this.label28.Text = "互卦卦辞";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(336, 15);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(53, 12);
            this.label29.TabIndex = 12;
            this.label29.Text = "本卦卦辞";
            // 
            // TimeBianGuaCHi
            // 
            this.TimeBianGuaCHi.Location = new System.Drawing.Point(396, 207);
            this.TimeBianGuaCHi.Name = "TimeBianGuaCHi";
            this.TimeBianGuaCHi.Size = new System.Drawing.Size(384, 85);
            this.TimeBianGuaCHi.TabIndex = 11;
            this.TimeBianGuaCHi.Text = "";
            // 
            // TimeBenGuaYao
            // 
            this.TimeBenGuaYao.Location = new System.Drawing.Point(825, 12);
            this.TimeBenGuaYao.Name = "TimeBenGuaYao";
            this.TimeBenGuaYao.Size = new System.Drawing.Size(421, 84);
            this.TimeBenGuaYao.TabIndex = 10;
            this.TimeBenGuaYao.Text = "";
            // 
            // TimeBenGuaChi
            // 
            this.TimeBenGuaChi.Location = new System.Drawing.Point(396, 12);
            this.TimeBenGuaChi.Name = "TimeBenGuaChi";
            this.TimeBenGuaChi.Size = new System.Drawing.Size(384, 85);
            this.TimeBenGuaChi.TabIndex = 9;
            this.TimeBenGuaChi.Text = "";
            // 
            // TimeBianGuaName
            // 
            this.TimeBianGuaName.Location = new System.Drawing.Point(236, 207);
            this.TimeBianGuaName.Name = "TimeBianGuaName";
            this.TimeBianGuaName.Size = new System.Drawing.Size(96, 85);
            this.TimeBianGuaName.TabIndex = 8;
            this.TimeBianGuaName.TabStop = false;
            // 
            // TimeBianGuax
            // 
            this.TimeBianGuax.Location = new System.Drawing.Point(134, 247);
            this.TimeBianGuax.Name = "TimeBianGuax";
            this.TimeBianGuax.Size = new System.Drawing.Size(96, 42);
            this.TimeBianGuax.TabIndex = 7;
            this.TimeBianGuax.TabStop = false;
            this.TimeBianGuax.Click += new System.EventHandler(this.pictureBox13_Click);
            // 
            // TimeBianGuas
            // 
            this.TimeBianGuas.Location = new System.Drawing.Point(134, 207);
            this.TimeBianGuas.Name = "TimeBianGuas";
            this.TimeBianGuas.Size = new System.Drawing.Size(96, 40);
            this.TimeBianGuas.TabIndex = 6;
            this.TimeBianGuas.TabStop = false;
            // 
            // TimeHuGuaName
            // 
            this.TimeHuGuaName.Location = new System.Drawing.Point(236, 109);
            this.TimeHuGuaName.Name = "TimeHuGuaName";
            this.TimeHuGuaName.Size = new System.Drawing.Size(96, 85);
            this.TimeHuGuaName.TabIndex = 5;
            this.TimeHuGuaName.TabStop = false;
            // 
            // TimeHuGuax
            // 
            this.TimeHuGuax.Location = new System.Drawing.Point(133, 148);
            this.TimeHuGuax.Name = "TimeHuGuax";
            this.TimeHuGuax.Size = new System.Drawing.Size(96, 42);
            this.TimeHuGuax.TabIndex = 4;
            this.TimeHuGuax.TabStop = false;
            // 
            // TimeHuGuaS
            // 
            this.TimeHuGuaS.Location = new System.Drawing.Point(133, 109);
            this.TimeHuGuaS.Name = "TimeHuGuaS";
            this.TimeHuGuaS.Size = new System.Drawing.Size(96, 40);
            this.TimeHuGuaS.TabIndex = 3;
            this.TimeHuGuaS.TabStop = false;
            // 
            // TimeBenGuaName
            // 
            this.TimeBenGuaName.Location = new System.Drawing.Point(236, 12);
            this.TimeBenGuaName.Name = "TimeBenGuaName";
            this.TimeBenGuaName.Size = new System.Drawing.Size(96, 85);
            this.TimeBenGuaName.TabIndex = 2;
            this.TimeBenGuaName.TabStop = false;
            // 
            // TimeBenGuax
            // 
            this.TimeBenGuax.Location = new System.Drawing.Point(131, 50);
            this.TimeBenGuax.Name = "TimeBenGuax";
            this.TimeBenGuax.Size = new System.Drawing.Size(96, 42);
            this.TimeBenGuax.TabIndex = 1;
            this.TimeBenGuax.TabStop = false;
            // 
            // TimeBenGuas
            // 
            this.TimeBenGuas.Location = new System.Drawing.Point(131, 12);
            this.TimeBenGuas.Name = "TimeBenGuas";
            this.TimeBenGuas.Size = new System.Drawing.Size(96, 40);
            this.TimeBenGuas.TabIndex = 0;
            this.TimeBenGuas.TabStop = false;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.label20.Font = new System.Drawing.Font("宋体", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label20.Location = new System.Drawing.Point(353, 40);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(49, 20);
            this.label20.TabIndex = 4;
            this.label20.Text = "阴历";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.label19.Font = new System.Drawing.Font("宋体", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label19.ForeColor = System.Drawing.Color.Black;
            this.label19.Location = new System.Drawing.Point(23, 40);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(49, 20);
            this.label19.TabIndex = 3;
            this.label19.Text = "阳历";
            // 
            // YinLi
            // 
            this.YinLi.AutoSize = true;
            this.YinLi.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.YinLi.Font = new System.Drawing.Font("宋体", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.YinLi.Location = new System.Drawing.Point(442, 40);
            this.YinLi.Name = "YinLi";
            this.YinLi.Size = new System.Drawing.Size(0, 20);
            this.YinLi.TabIndex = 2;
            // 
            // YaLI
            // 
            this.YaLI.AutoSize = true;
            this.YaLI.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.YaLI.Font = new System.Drawing.Font("宋体", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.YaLI.Location = new System.Drawing.Point(98, 38);
            this.YaLI.Name = "YaLI";
            this.YaLI.Size = new System.Drawing.Size(0, 20);
            this.YaLI.TabIndex = 1;
            // 
            // GetTime
            // 
            this.GetTime.Location = new System.Drawing.Point(225, 140);
            this.GetTime.Name = "GetTime";
            this.GetTime.Size = new System.Drawing.Size(135, 23);
            this.GetTime.TabIndex = 0;
            this.GetTime.Text = "根据当前时间";
            this.GetTime.UseVisualStyleBackColor = true;
            this.GetTime.Click += new System.EventHandler(this.GetTime_Click);
            // 
            // TPRMB
            // 
            this.TPRMB.BackColor = System.Drawing.Color.DimGray;
            this.TPRMB.Controls.Add(this.textBox1);
            this.TPRMB.Controls.Add(this.button4);
            this.TPRMB.Controls.Add(this.dateTimePicker2);
            this.TPRMB.Location = new System.Drawing.Point(4, 22);
            this.TPRMB.Name = "TPRMB";
            this.TPRMB.Padding = new System.Windows.Forms.Padding(3);
            this.TPRMB.Size = new System.Drawing.Size(1241, 724);
            this.TPRMB.TabIndex = 2;
            this.TPRMB.Text = "毕达歌拉斯";
            this.TPRMB.UseVisualStyleBackColor = true;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(548, 150);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox1.Size = new System.Drawing.Size(534, 503);
            this.textBox1.TabIndex = 9;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(492, 111);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 23);
            this.button4.TabIndex = 8;
            this.button4.Text = "test";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Location = new System.Drawing.Point(440, 53);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(200, 21);
            this.dateTimePicker2.TabIndex = 7;
            // 
            // tabPage4
            // 
            this.tabPage4.BackColor = System.Drawing.Color.DimGray;
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(1241, 724);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "尺寸占";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // tabPage5
            // 
            this.tabPage5.BackColor = System.Drawing.Color.Gray;
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(1241, 724);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "方位占";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // GetTool
            // 
            this.GetTool.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("GetTool.BackgroundImage")));
            this.GetTool.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.GetTool.Controls.Add(this.benguaguachi);
            this.GetTool.Controls.Add(this.bianguaguachi);
            this.GetTool.Controls.Add(this.huguaguachi);
            this.GetTool.Controls.Add(this.zongguaguachi);
            this.GetTool.Controls.Add(this.cuoguaguachi);
            this.GetTool.Controls.Add(this.button2);
            this.GetTool.Controls.Add(this.TBNumB);
            this.GetTool.Controls.Add(this.label17);
            this.GetTool.Controls.Add(this.label18);
            this.GetTool.Controls.Add(this.TBNumA);
            this.GetTool.Controls.Add(this.label16);
            this.GetTool.Controls.Add(this.PBZongGuaName);
            this.GetTool.Controls.Add(this.PBZongGuaX);
            this.GetTool.Controls.Add(this.PBZongGuaS);
            this.GetTool.Controls.Add(this.label15);
            this.GetTool.Controls.Add(this.PBCuoGuaName);
            this.GetTool.Controls.Add(this.PBCuoGuaX);
            this.GetTool.Controls.Add(this.PBCuoGuaS);
            this.GetTool.Controls.Add(this.label14);
            this.GetTool.Controls.Add(this.bianguaPBname);
            this.GetTool.Controls.Add(this.bianguaxyao);
            this.GetTool.Controls.Add(this.bianguasyao);
            this.GetTool.Controls.Add(this.label7);
            this.GetTool.Controls.Add(this.PBHuGuaName);
            this.GetTool.Controls.Add(this.PBHuGuaX);
            this.GetTool.Controls.Add(this.PBHuGuaS);
            this.GetTool.Controls.Add(this.label6);
            this.GetTool.Controls.Add(this.PBBenGuaName);
            this.GetTool.Controls.Add(this.PBBenGuaX);
            this.GetTool.Controls.Add(this.PBBenGuaS);
            this.GetTool.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.GetTool.Location = new System.Drawing.Point(4, 22);
            this.GetTool.Name = "GetTool";
            this.GetTool.Padding = new System.Windows.Forms.Padding(3);
            this.GetTool.Size = new System.Drawing.Size(1241, 724);
            this.GetTool.TabIndex = 5;
            this.GetTool.Text = "研究工具";
            this.GetTool.UseVisualStyleBackColor = true;
            // 
            // benguaguachi
            // 
            this.benguaguachi.Location = new System.Drawing.Point(430, 191);
            this.benguaguachi.Name = "benguaguachi";
            this.benguaguachi.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.None;
            this.benguaguachi.Size = new System.Drawing.Size(379, 219);
            this.benguaguachi.TabIndex = 42;
            this.benguaguachi.Text = "";
            this.benguaguachi.Visible = false;
            // 
            // bianguaguachi
            // 
            this.bianguaguachi.Location = new System.Drawing.Point(972, 578);
            this.bianguaguachi.Name = "bianguaguachi";
            this.bianguaguachi.Size = new System.Drawing.Size(263, 96);
            this.bianguaguachi.TabIndex = 41;
            this.bianguaguachi.Text = "";
            this.bianguaguachi.Visible = false;
            // 
            // huguaguachi
            // 
            this.huguaguachi.Location = new System.Drawing.Point(6, 580);
            this.huguaguachi.Name = "huguaguachi";
            this.huguaguachi.Size = new System.Drawing.Size(263, 96);
            this.huguaguachi.TabIndex = 40;
            this.huguaguachi.Text = "";
            this.huguaguachi.Visible = false;
            // 
            // zongguaguachi
            // 
            this.zongguaguachi.Location = new System.Drawing.Point(6, 385);
            this.zongguaguachi.Name = "zongguaguachi";
            this.zongguaguachi.Size = new System.Drawing.Size(263, 96);
            this.zongguaguachi.TabIndex = 39;
            this.zongguaguachi.Text = "";
            this.zongguaguachi.Visible = false;
            // 
            // cuoguaguachi
            // 
            this.cuoguaguachi.Location = new System.Drawing.Point(972, 385);
            this.cuoguaguachi.Name = "cuoguaguachi";
            this.cuoguaguachi.Size = new System.Drawing.Size(263, 96);
            this.cuoguaguachi.TabIndex = 38;
            this.cuoguaguachi.Text = "";
            this.cuoguaguachi.Visible = false;
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("宋体", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button2.Location = new System.Drawing.Point(530, 566);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(194, 41);
            this.button2.TabIndex = 37;
            this.button2.Text = "开始占卜";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // TBNumB
            // 
            this.TBNumB.Location = new System.Drawing.Point(934, 14);
            this.TBNumB.Multiline = true;
            this.TBNumB.Name = "TBNumB";
            this.TBNumB.Size = new System.Drawing.Size(121, 33);
            this.TBNumB.TabIndex = 36;
            this.TBNumB.Text = "1";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("宋体", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label17.Location = new System.Drawing.Point(825, 12);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(103, 35);
            this.label17.TabIndex = 35;
            this.label17.Text = "数字B";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("宋体", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label18.Location = new System.Drawing.Point(174, 14);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(95, 33);
            this.label18.TabIndex = 34;
            this.label18.Text = "数字A";
            // 
            // TBNumA
            // 
            this.TBNumA.Location = new System.Drawing.Point(293, 14);
            this.TBNumA.Multiline = true;
            this.TBNumA.Name = "TBNumA";
            this.TBNumA.Size = new System.Drawing.Size(100, 33);
            this.TBNumA.TabIndex = 33;
            this.TBNumA.Text = "1";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(20, 314);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(29, 12);
            this.label16.TabIndex = 32;
            this.label16.Text = "综卦";
            // 
            // PBZongGuaName
            // 
            this.PBZongGuaName.Location = new System.Drawing.Point(168, 282);
            this.PBZongGuaName.Name = "PBZongGuaName";
            this.PBZongGuaName.Size = new System.Drawing.Size(96, 85);
            this.PBZongGuaName.TabIndex = 31;
            this.PBZongGuaName.TabStop = false;
            // 
            // PBZongGuaX
            // 
            this.PBZongGuaX.Location = new System.Drawing.Point(63, 320);
            this.PBZongGuaX.Name = "PBZongGuaX";
            this.PBZongGuaX.Size = new System.Drawing.Size(96, 42);
            this.PBZongGuaX.TabIndex = 30;
            this.PBZongGuaX.TabStop = false;
            // 
            // PBZongGuaS
            // 
            this.PBZongGuaS.Location = new System.Drawing.Point(63, 282);
            this.PBZongGuaS.Name = "PBZongGuaS";
            this.PBZongGuaS.Size = new System.Drawing.Size(96, 40);
            this.PBZongGuaS.TabIndex = 29;
            this.PBZongGuaS.TabStop = false;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(1206, 327);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(29, 12);
            this.label15.TabIndex = 28;
            this.label15.Text = "错卦";
            // 
            // PBCuoGuaName
            // 
            this.PBCuoGuaName.Location = new System.Drawing.Point(972, 295);
            this.PBCuoGuaName.Name = "PBCuoGuaName";
            this.PBCuoGuaName.Size = new System.Drawing.Size(96, 85);
            this.PBCuoGuaName.TabIndex = 27;
            this.PBCuoGuaName.TabStop = false;
            // 
            // PBCuoGuaX
            // 
            this.PBCuoGuaX.Location = new System.Drawing.Point(1074, 337);
            this.PBCuoGuaX.Name = "PBCuoGuaX";
            this.PBCuoGuaX.Size = new System.Drawing.Size(96, 42);
            this.PBCuoGuaX.TabIndex = 26;
            this.PBCuoGuaX.TabStop = false;
            // 
            // PBCuoGuaS
            // 
            this.PBCuoGuaS.Location = new System.Drawing.Point(1074, 299);
            this.PBCuoGuaS.Name = "PBCuoGuaS";
            this.PBCuoGuaS.Size = new System.Drawing.Size(96, 40);
            this.PBCuoGuaS.TabIndex = 25;
            this.PBCuoGuaS.TabStop = false;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(913, 569);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(29, 12);
            this.label14.TabIndex = 24;
            this.label14.Text = "变卦";
            // 
            // bianguaPBname
            // 
            this.bianguaPBname.Location = new System.Drawing.Point(972, 491);
            this.bianguaPBname.Name = "bianguaPBname";
            this.bianguaPBname.Size = new System.Drawing.Size(96, 85);
            this.bianguaPBname.TabIndex = 23;
            this.bianguaPBname.TabStop = false;
            // 
            // bianguaxyao
            // 
            this.bianguaxyao.Location = new System.Drawing.Point(1074, 529);
            this.bianguaxyao.Name = "bianguaxyao";
            this.bianguaxyao.Size = new System.Drawing.Size(96, 42);
            this.bianguaxyao.TabIndex = 22;
            this.bianguaxyao.TabStop = false;
            // 
            // bianguasyao
            // 
            this.bianguasyao.Location = new System.Drawing.Point(1074, 491);
            this.bianguasyao.Name = "bianguasyao";
            this.bianguasyao.Size = new System.Drawing.Size(96, 40);
            this.bianguasyao.TabIndex = 21;
            this.bianguasyao.TabStop = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(305, 571);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(29, 12);
            this.label7.TabIndex = 20;
            this.label7.Text = "互卦";
            // 
            // PBHuGuaName
            // 
            this.PBHuGuaName.Location = new System.Drawing.Point(168, 493);
            this.PBHuGuaName.Name = "PBHuGuaName";
            this.PBHuGuaName.Size = new System.Drawing.Size(96, 85);
            this.PBHuGuaName.TabIndex = 19;
            this.PBHuGuaName.TabStop = false;
            // 
            // PBHuGuaX
            // 
            this.PBHuGuaX.Location = new System.Drawing.Point(63, 531);
            this.PBHuGuaX.Name = "PBHuGuaX";
            this.PBHuGuaX.Size = new System.Drawing.Size(96, 42);
            this.PBHuGuaX.TabIndex = 18;
            this.PBHuGuaX.TabStop = false;
            // 
            // PBHuGuaS
            // 
            this.PBHuGuaS.Location = new System.Drawing.Point(63, 493);
            this.PBHuGuaS.Name = "PBHuGuaS";
            this.PBHuGuaS.Size = new System.Drawing.Size(96, 40);
            this.PBHuGuaS.TabIndex = 17;
            this.PBHuGuaS.TabStop = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(499, 108);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(29, 12);
            this.label6.TabIndex = 16;
            this.label6.Text = "本卦";
            // 
            // PBBenGuaName
            // 
            this.PBBenGuaName.Location = new System.Drawing.Point(636, 105);
            this.PBBenGuaName.Name = "PBBenGuaName";
            this.PBBenGuaName.Size = new System.Drawing.Size(96, 85);
            this.PBBenGuaName.TabIndex = 15;
            this.PBBenGuaName.TabStop = false;
            // 
            // PBBenGuaX
            // 
            this.PBBenGuaX.Location = new System.Drawing.Point(531, 143);
            this.PBBenGuaX.Name = "PBBenGuaX";
            this.PBBenGuaX.Size = new System.Drawing.Size(96, 42);
            this.PBBenGuaX.TabIndex = 14;
            this.PBBenGuaX.TabStop = false;
            // 
            // PBBenGuaS
            // 
            this.PBBenGuaS.Location = new System.Drawing.Point(531, 105);
            this.PBBenGuaS.Name = "PBBenGuaS";
            this.PBBenGuaS.Size = new System.Drawing.Size(96, 40);
            this.PBBenGuaS.TabIndex = 13;
            this.PBBenGuaS.TabStop = false;
            // 
            // TPFangTu
            // 
            this.TPFangTu.AutoScroll = true;
            this.TPFangTu.Location = new System.Drawing.Point(4, 22);
            this.TPFangTu.Name = "TPFangTu";
            this.TPFangTu.Padding = new System.Windows.Forms.Padding(3);
            this.TPFangTu.Size = new System.Drawing.Size(1241, 724);
            this.TPFangTu.TabIndex = 6;
            this.TPFangTu.Text = "六十四卦方图";
            this.TPFangTu.UseVisualStyleBackColor = true;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(9, 50);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(0, 12);
            this.label32.TabIndex = 16;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(9, 148);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(0, 12);
            this.label33.TabIndex = 17;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(9, 247);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(0, 12);
            this.label34.TabIndex = 18;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(7, 50);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(0, 12);
            this.label35.TabIndex = 16;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(9, 148);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(0, 12);
            this.label36.TabIndex = 17;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(9, 247);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(0, 12);
            this.label37.TabIndex = 18;
            // 
            // 玄学研究工具
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(1254, 742);
            this.Controls.Add(this.tabpageGuaTool);
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "玄学研究工具";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "玄学研究工具";
            this.tabpageGuaTool.ResumeLayout(false);
            this.TPnum.ResumeLayout(false);
            this.TPnum.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            this.Result.ResumeLayout(false);
            this.Result.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.TPtime.ResumeLayout(false);
            this.TPtime.PerformLayout();
            this.timeresult.ResumeLayout(false);
            this.timeresult.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.TimeBianGuaName)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TimeBianGuax)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TimeBianGuas)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TimeHuGuaName)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TimeHuGuax)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TimeHuGuaS)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TimeBenGuaName)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TimeBenGuax)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TimeBenGuas)).EndInit();
            this.TPRMB.ResumeLayout(false);
            this.TPRMB.PerformLayout();
            this.GetTool.ResumeLayout(false);
            this.GetTool.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PBZongGuaName)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBZongGuaX)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBZongGuaS)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBCuoGuaName)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBCuoGuaX)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBCuoGuaS)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bianguaPBname)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bianguaxyao)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bianguasyao)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBHuGuaName)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBHuGuaX)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBHuGuaS)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBBenGuaName)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBBenGuaX)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBBenGuaS)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabpageGuaTool;
        private System.Windows.Forms.TabPage TPnum;
        private System.Windows.Forms.TabPage TPtime;
        private System.Windows.Forms.TabPage TPRMB;
        private System.Windows.Forms.TextBox NumB;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox NumA;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.Panel Result;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.RichTextBox RTBYaoChi;
        private System.Windows.Forms.RichTextBox RTBGuaChi;
        private System.Windows.Forms.TabPage GetTool;
        private System.Windows.Forms.RichTextBox RTBBGGC;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.RichTextBox RTBHGYC;
        private System.Windows.Forms.RichTextBox RTBHGGC;
        private System.Windows.Forms.RichTextBox RTBBGYC;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.TabPage TPFangTu;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.PictureBox PBBenGuaName;
        private System.Windows.Forms.PictureBox PBBenGuaX;
        private System.Windows.Forms.PictureBox PBBenGuaS;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.PictureBox PBZongGuaName;
        private System.Windows.Forms.PictureBox PBZongGuaX;
        private System.Windows.Forms.PictureBox PBZongGuaS;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.PictureBox PBCuoGuaName;
        private System.Windows.Forms.PictureBox PBCuoGuaX;
        private System.Windows.Forms.PictureBox PBCuoGuaS;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.PictureBox bianguaPBname;
        private System.Windows.Forms.PictureBox bianguaxyao;
        private System.Windows.Forms.PictureBox bianguasyao;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.PictureBox PBHuGuaName;
        private System.Windows.Forms.PictureBox PBHuGuaX;
        private System.Windows.Forms.PictureBox PBHuGuaS;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox TBNumB;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox TBNumA;
        private System.Windows.Forms.RichTextBox benguaguachi;
        private System.Windows.Forms.RichTextBox bianguaguachi;
        private System.Windows.Forms.RichTextBox huguaguachi;
        private System.Windows.Forms.RichTextBox zongguaguachi;
        private System.Windows.Forms.RichTextBox cuoguaguachi;
        private System.Windows.Forms.Label YinLi;
        private System.Windows.Forms.Label YaLI;
        private System.Windows.Forms.Button GetTime;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Panel timeresult;
        private System.Windows.Forms.RichTextBox TimeHuGuaYao;
        private System.Windows.Forms.RichTextBox TimeHuGuaChi;
        private System.Windows.Forms.RichTextBox TimeBianGuaYao;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.RichTextBox TimeBianGuaCHi;
        private System.Windows.Forms.RichTextBox TimeBenGuaYao;
        private System.Windows.Forms.RichTextBox TimeBenGuaChi;
        private System.Windows.Forms.PictureBox TimeBianGuaName;
        private System.Windows.Forms.PictureBox TimeBianGuax;
        private System.Windows.Forms.PictureBox TimeBianGuas;
        private System.Windows.Forms.PictureBox TimeHuGuaName;
        private System.Windows.Forms.PictureBox TimeHuGuax;
        private System.Windows.Forms.PictureBox TimeHuGuaS;
        private System.Windows.Forms.PictureBox TimeBenGuaName;
        private System.Windows.Forms.PictureBox TimeBenGuax;
        private System.Windows.Forms.PictureBox TimeBenGuas;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label35;


    }
}