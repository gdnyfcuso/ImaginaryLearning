﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Windows.Forms;
using System.IO;

namespace suangua
{

    public static class huagua
    {
        public static int NumA { get; set; }//获得上卦数字
        public static int NumB { get; set; }//获得上卦数字
        static string[,] getGuaName = new string[8, 8] 
            {   { "乾", "夬", "大有", "大壮", "小畜", "需", "大畜", "泰" },
                { "履", "兑", "睽", "归妹", "中孚", "节", "损", "临" }, 
                {"同人","革","离","丰","家人","既济","贲","明夷"}, 
                {"无妄","随","噬嗑","震","益","屯","颐","复"},
                {"姤","大过","鼎","恒","巽","井","蛊","升"},
                {"讼","困","未济","解","涣","坎","蒙","师"},
                {"遁","咸","旅","小过","渐","蹇","艮","谦"},
                {"否","萃","晋","豫","观","比","剥","坤"}
            };//通过字符串数组存储六十四卦卦名
        public static int SuanDongYao(int NumA, int NumB, DateTime da, bool IsTimeZhan)//计算本卦的动爻
        {
            int dongYao = 0;
            if (IsTimeZhan)
            {
                //时间占算动爻的时候,只以年地支+月数+日数+时数/6
                //dongYao = (YinLiChangeYangLi.numa+YinLiChangeYangLi.numb) % 6;
                dongYao = YinLiChangeYangLi.numb % 6;

                if (dongYao == 0)
                {
                    dongYao = 6;
                }
            }
            else
            {

                dongYao = (NumA + NumB + YinLiChangeYangLi.GetDiZhiNum(da)) % 6;
                if (dongYao == 0)
                {
                    dongYao = 6;
                }

            }
            //int dongYao = (NumA + NumB) % 6;
            //if (dongYao == 0)
            //{
            //    dongYao = 6;
            //}
            return dongYao;

        }
        public static void GetGuaChi(int upGua, int downGua, out string GuaChi, out string YaoChi, DateTime da, out int doyao, bool Istime)//读取文件里面的卦辞和爻辞
        {


            string path = @".\GuaDataBase\" + getGuaName[downGua, upGua] + ".txt";//获得文件路径

            FileStream Gua = new FileStream(path, FileMode.Open, FileAccess.Read);
            StreamReader strRea = new StreamReader(Gua);
            string str1 = strRea.ReadToEnd();
            string[] fenGua = str1.Split('|');
            GuaChi = fenGua[0];
            int dongyao = SuanDongYao(NumA, NumB, da, Istime);
            //将此值传出,以供算体用,与五行而作
            doyao = dongyao;
            YaoChi = fenGua[dongyao];

        }
        public static Image GetGuaName(int upGua, int downGua, float m, float n)//get含有卦名的图片
        {

            string g = getGuaName[downGua, upGua];

            Bitmap guaName = new Bitmap(130, 117);
            Graphics gName = Graphics.FromImage(guaName);
            Pen red = new Pen(Color.Red, 10);
            Font f = new Font("宋体", 30);
            Brush br = new SolidBrush(Color.Black);

            gName.DrawString(g, f, br, m, n);
            return guaName;
        }
        public static void YinYao(Point p0, out Point p1, out Point p2, out Point p3, out Point p4)//阴爻坐标点算法
        {
            Point p11 = new Point();
            p11.X = p0.X;
            p11.Y = p0.Y + 10;
            p1 = p11;
            Point p12 = new Point();
            p12.X = p1.X + 40;
            p12.Y = p1.Y;
            p2 = p12;
            Point p13 = new Point();
            p13.X = p1.X + 56;
            p13.Y = p1.Y;
            p3 = p13;
            Point p14 = new Point();
            p14.X = p1.X + 100;
            p14.Y = p1.Y;
            p4 = p14;

        }
        public static void YangYao(Point p0, out Point p1, out Point p2)//阳爻坐标点算法
        {
            Point p11 = new Point();
            p11.X = p0.X;
            p11.Y = p0.Y + 10;
            p1 = p11;
            Point p12 = new Point();
            p12.X = p1.X + 100;
            p12.Y = p1.Y;
            p2 = p12;


        }
        public static string daoxu(string d)//将字符串倒着输出
        {
            string SS = null;
            int num = d.Length;
            for (int i = d.Length - 1; i >= 0; i--)
            {
                SS += d[i];
            }
            if (num < 3)
            {
                for (int j = 0; j < 3 - num; j++)
                {
                    SS = SS + "0";

                }
            }

            return SS;
        }
        public static Image HuadanGua(int sd, int x, int y)
        {

            Bitmap bit = new Bitmap(96, 98);
            Graphics gra = Graphics.FromImage(bit);
            Pen redPen = new Pen(Color.Red, 8);
            Point BaoLiuDian = new Point(x, y);
            string Sd = daoxu(GetErJinZhi(sd));
            for (int j = 0; j < Sd.Length; j++)
            {
                if (Sd.Substring(j, 1) == "1")
                {

                    Point p01 = new Point(0, 0);
                    Point p02 = new Point(0, 0);
                    Point p03 = new Point(0, 0);
                    Point p04 = new Point(0, 0);//初始化四坐标点
                    YinYao(BaoLiuDian, out p01, out p02, out p03, out p04);//调用函数算出阴爻的四个人坐标点
                    gra.DrawLine(redPen, p01, p02);
                    gra.DrawLine(redPen, p03, p04);
                    BaoLiuDian = p01;
                }
                else
                {
                    Point p01 = new Point(0, 0);
                    Point p02 = new Point(0, 0);//初始化两坐标点
                    YangYao(BaoLiuDian, out p01, out p02);//调用函数算出阳爻的两个人坐标点
                    gra.DrawLine(redPen, p01, p02);
                    BaoLiuDian = p01;//将推算的坐标点保留，以便下次使用

                }
            }
            return bit;




        }
        public static void GetZongGua(ref int up, ref int down)
        {
            string zongGuaUpDown = daoxu(GetErJinZhi(up)) + daoxu(GetErJinZhi(down));
            string str = daoxu(zongGuaUpDown);
            up = GetShiJinZhi(str.Substring(0, 3));
            down = GetShiJinZhi(str.Substring(3, 3));

        }
        public static void GetCuoGua(ref int up, ref int down)
        {
            string bingUpDown = daoxu(GetErJinZhi(up)) + daoxu(GetErJinZhi(down));
            string resuletUpDown = null;
            for (int i = 0; i < bingUpDown.Length; i++)
            {
                if (bingUpDown[i] == '1')
                {
                    resuletUpDown += "0";

                }
                else
                {
                    if (bingUpDown[i] == '0')
                    {
                        resuletUpDown += "1";
                    }
                }
            }
            up = GetShiJinZhi(resuletUpDown.Substring(0, 3));
            down = GetShiJinZhi(resuletUpDown.Substring(3, 3));


        }
        public static void GetHuGuaUpDown(ref int up, ref int down)
        {
            string bingUpDown = daoxu(GetErJinZhi(up)) + daoxu(GetErJinZhi(down));
            up = GetShiJinZhi(bingUpDown.Substring(1, 3));
            down = GetShiJinZhi(bingUpDown.Substring(2, 3));

        }
        public static void GetBianGuaUpDown(ref int up, ref int down, DateTime da, bool istime)//获得上卦或下卦动爻变动之后的上卦数字或下卦数字并返回计算值
        {
            int dongYao = SuanDongYao(NumA, NumB, da, istime);
            if (dongYao <= 3 && dongYao >= 0)
            {
                down = GetUpOrDown(down, dongYao);
            }
            else
            {
                if (dongYao >= 4 && dongYao <= 6)
                {
                    up = GetUpOrDown(up, dongYao - 3);

                }

            }

        }
        public static string GetErJinZhi(int d)//十进制转二进制
        {
            return Convert.ToString(d, 2);

        }
        public static int GetShiJinZhi(string s)//二进制转十进制
        {
            int j = 0;
            for (int i = 0; i < s.Length; i++)
            {
                if (s[i] == '1')
                {
                    if (i == 0)
                    {
                        j += 1;
                    }
                    else
                    {
                        for (int jn = 0; jn < i; jn++)
                        {
                            j += 2;

                        }
                    }
                }

            }
            return j;

        }
        public static int GetUpOrDown(int upordown, int dongYao)//返回转换后十进制数字
        {
            string BianLing = daoxu(daoxu(GetErJinZhi(upordown)));
            if (BianLing.Substring(dongYao - 1, 1) == "1")
            {
                string str = null;
                for (int i = 0; i < BianLing.Length; i++)
                {
                    if (i == dongYao - 1)
                    {
                        str += "0";
                        continue;


                    }
                    str += BianLing.Substring(i, 1);

                }
                return GetShiJinZhi(daoxu(str));
            }
            else
            {
                string str = null;
                for (int i = 0; i < BianLing.Length; i++)
                {
                    if (i == dongYao - 1)
                    {
                        str += "1";
                        continue;


                    }
                    str += BianLing.Substring(i, 1);

                }
                return GetShiJinZhi(daoxu(str));

            }

        }

        public static Dictionary<int, string> wuxing = new Dictionary<int, string>();
        public static Dictionary<string,string> wuxingshengke=new Dictionary<string, string>(); 

        static huagua()
        {
            wuxing.Add(0, "金");
            wuxing.Add(1, "金");
            wuxing.Add(2,"火");
            wuxing.Add(3,"木");
            wuxing.Add(4, "木");
            wuxing.Add(5, "水");
            wuxing.Add(6, "土");
            wuxing.Add(7, "土");
            wuxingshengke.Add("金木","金克木");
            wuxingshengke.Add("金火","火克金");
            wuxingshengke.Add("金水","金生水");
            wuxingshengke.Add("金土", "土生金");           
            wuxingshengke.Add("水木", "水生木");
            wuxingshengke.Add("水火", "水克火");
            wuxingshengke.Add("水土", "土克水");
            wuxingshengke.Add("木火", "木生火");
            wuxingshengke.Add("木土", "木克土");
            wuxingshengke.Add("火土", "火生土");
            



            

        }
        public static string GetTiYongWuXing(int guaUp, int guaDown, int dongYao)
        {
            //根据传进来的卦数字,找出对应五行元素,及体用关系,包含是克还是生,还是比和
            StringBuilder stringBuilder=new StringBuilder();
            string upstring = wuxing[guaUp],downstring=wuxing[guaDown];
            
            if (dongYao>3)
            {
                stringBuilder.Append("上卦为:用,属:"+upstring+"\r\n");
                stringBuilder.Append("下卦为:体,属:"+downstring+"\r\n");
                stringBuilder.Append(GetWuxingXiangKe(upstring, downstring));
            }
            else
            {

                stringBuilder.Append("上卦为:体,属:" + upstring + "\r\n");
                stringBuilder.Append("下卦为:用,属:" + downstring + "\r\n");
                stringBuilder.Append(GetWuxingXiangKe(upstring, downstring));
            }

            return stringBuilder.ToString();
        }

         static string GetWuxingXiangKe(string upstring,string downstring)
        {
            StringBuilder stringBuilder=new StringBuilder();
            if (!string.IsNullOrEmpty(upstring)&&!string.IsNullOrEmpty(downstring))
            {
                if (upstring.Equals(downstring))
                {
                    stringBuilder.Append("相比合");
                }
                else
                {
                    if (wuxingshengke.ContainsKey(upstring+downstring))
                    {
                        stringBuilder.Append(wuxingshengke[upstring + downstring]);
                    }
                    else
                    {
                        stringBuilder.Append(wuxingshengke[downstring + upstring]);
                    }
                }
            }

            return stringBuilder.ToString();
        }

    }
}
