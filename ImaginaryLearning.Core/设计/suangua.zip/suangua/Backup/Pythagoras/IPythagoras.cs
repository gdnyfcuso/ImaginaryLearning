﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.IO;


namespace Pythagoras
{
    public interface IPythagoras
    {
        /// <summary>
        /// 传进来要使用的数据
        /// </summary>
        Dictionary<int, int> PythagorasDaga { get; set; }
       /// <summary>
       /// 返回相应的图片
       /// </summary>
       /// <returns></returns>
        Image GetPicture();
        /// <summary>
        /// 获得文本资料
        /// </summary>
        /// <returns></returns>
        string GetResult();

    }
}
