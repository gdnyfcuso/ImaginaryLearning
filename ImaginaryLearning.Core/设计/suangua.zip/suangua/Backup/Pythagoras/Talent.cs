﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.IO;

namespace Pythagoras
{
    public class Talent : IPythagoras
    {
        public Dictionary<int, int> PythagorasDaga { get; set; }
        public Talent(Dictionary<int,int> pythagorasDaga )
        {
            this.PythagorasDaga = pythagorasDaga;
        }

    public Image GetPicture()
        {
            throw new NotImplementedException();
        }

    #region 读取天赋数的文本数据
    public string GetResult()
    {
        string ResultString = string.Empty;
        foreach (var i in PythagorasDaga.Keys)
        {

            if (PythagorasDaga[i] >= 3)
            {
                ResultString += StringHelp.GetTxt(i.ToString(), 1);

            }

        }
        for (int i = 1; i < 10; i++)
        {
            if (!PythagorasDaga.ContainsKey(i))
            {
                ResultString += StringHelp.GetTxt(i.ToString(), 2);
            }
        }

        return ResultString;
    }
        
    #endregion
    }
}
