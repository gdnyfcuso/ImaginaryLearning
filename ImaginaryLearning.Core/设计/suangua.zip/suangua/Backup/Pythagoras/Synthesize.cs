﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;

namespace Pythagoras
{
    public class Synthesize : IPythagoras
    {
        public Dictionary<int, int> PythagorasDaga { get; set; }
        //要比对的路径源
        private List<string> pathTempList = new List<string>() { "123", "456", "789", "147", "258", "369", "159", "357", "24", "26", "68", "48" };
        //路径临时存储区
        private  List<string> pathLists = new List<string>();

        public Synthesize(List<string> myList)
        {
            //初始化文件路径库
            InitPathListS(myList, pathTempList);
            //并且初始化集合库pathLists

        }
        #region 挑选出传过来的集合里面符合路径源的数据,并放到集合里面去以供下次使用

        private void InitPathListS(List<string> ListA, List<string> ListB)
        {


            foreach (var VARIABLE in ListB)
            {
                if (IsHas(VARIABLE, ListA))
                {
                    pathLists.Add(VARIABLE);
                }
            }

        }

        private bool IsHas(string tempString, List<string> listB)
        {
            bool isflay = false;
            foreach (string VARIABLE in listB)
            {
                if (CompareStringByChar(VARIABLE, tempString))
                {
                    isflay = true;
                    break;

                }
            }

            return isflay;

        }
        
        #endregion

        #region 判断两个字符串是否相等,没有顺序限制
        private bool CompareStringByChar(string strA, string strB)
        {
            bool IsEqual = true;
            char[] arrA = strA.ToCharArray();
            char[] arrB = strB.ToCharArray();
            foreach (char chara in arrA)
            {
                if (!strB.Contains(chara))
                {
                    IsEqual = false;
                }
            }
            foreach (char charb in arrB)
            {
                if (!strA.Contains(charb))
                {
                    IsEqual = false;
                }
            }
            return IsEqual;
        } 
        #endregion





        public Image GetPicture()
        {
            throw new NotImplementedException();
        }
        /// <summary>
        /// 综合分析
        /// </summary>
        /// <returns></returns>
        public string GetResult()
        {
            string tempstring = string.Empty;
            //第一步拿到全排列的list集合:mylist

            //第二步:将集合里面的数据进行比对,选出里面数字一样的集合

            //临时集合里面取出相应的地址去读取文件
            if (pathLists.Count != 0)
            {
                for (int i = 0; i < pathLists.Count; i++)
                {
                    tempstring += StringHelp.GetTxt(pathLists[i], 0);
                }
                if (pathLists.Count > 4)
                {
                    tempstring += "同时也说明了做事不专心";
                }
            }
            else
            {
                tempstring += "执行力强,雷厉风行,说到做到";
            }
        
            return tempstring;

        }
    }
}
