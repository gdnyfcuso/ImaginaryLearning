﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;

namespace Pythagoras
{
   public class Vitality:IPythagoras
    {
        public Dictionary<int, int> PythagorasDaga { get; set; }

        public Vitality(Dictionary<int,int> PythagorasDaga )
        {
            this.PythagorasDaga = PythagorasDaga;
        }

        public Image GetPicture()
        {
            throw new NotImplementedException();
        }

        public string GetResult()
        {
            string tempString = string.Empty;
            foreach (var key in PythagorasDaga.Keys)
            {
                tempString += StringHelp.GetTxt("1" + key, 0);
                if(PythagorasDaga[key]>=3)
                {
                    tempString += StringHelp.GetTxt("1" + key, 1);

                }
            }
            return tempString;

        }
    }
}
