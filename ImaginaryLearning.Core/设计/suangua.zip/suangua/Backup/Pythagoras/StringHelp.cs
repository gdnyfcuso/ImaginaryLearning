﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace Pythagoras
{
    public class StringHelp
    {
        #region 辅助读取文件
        public static string GetTxt(string PathIndex, int txtIndex)
        {
            FileStream Gua = new FileStream(@".\Pythagoras\" + PathIndex + ".txt", FileMode.Open, FileAccess.Read);
            StreamReader strRea = new StreamReader(Gua);
            string tempst = strRea.ReadToEnd();

            return tempst.Split('|')[txtIndex] + "\r\n";
        } 
        #endregion
    }
}
