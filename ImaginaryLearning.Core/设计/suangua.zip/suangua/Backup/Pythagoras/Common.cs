﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.IO;

namespace Pythagoras
{
    public class Common : IPythagoras
    {
        public Dictionary<int, int> PythagorasDaga { get; set; }

        public Common(Dictionary<int, int> PythagorasDaga)
        {
            this.PythagorasDaga = PythagorasDaga;
        }

        public Image GetPicture()
        {
            throw new NotImplementedException();
        }

        public string GetResult()
        {
            string ResultString = string.Empty;

            foreach (var i in PythagorasDaga.Keys)
            {

                if (i != 0)
                {
                   ResultString+= StringHelp.GetTxt(i.ToString(), 0);

                }
            }
            return ResultString;

        }
    }
}
