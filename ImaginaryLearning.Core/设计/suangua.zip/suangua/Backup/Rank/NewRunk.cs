﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Rank
{
    public class NewRunk
    {
        public static int[] seq = { 1, 2, 3, 8, 9 };//algorithm of Permutation
      public  static List<string> tempString = new List<string>();
        public static void PrintSeq(int[] s)
        {
            string mytempstring = string.Empty;
            for (int i = 0; i < s.Length; i++)
            {
                mytempstring += s[i].ToString();

            }

                tempString.Add(mytempstring);
            
           

        }
        public static int Fac(int n)
        {
            int nRet = 1;
            for (int i = 2; i <= n; i++)
                nRet *= i;
            return nRet;
        }
        public static int CountC(int n, int r)
        {
            return Fac(n) / Fac(n - r) / Fac(r);
        }

        #region 组合运算
        public static void P(int n)
        {
            int[] a = new int[n];
            for (int i = 0; i < n; i++) a[i] = seq[i];
            PrintSeq(a);
            int nCount = Fac(n);
            for (int k = 1; k < nCount; k++)
            {
                int m = n - 2;
                while (a[m] > a[m + 1]) m--;
                int q = n - 1;
                while (a[q] < a[m]) q--;
                int tmp;
                tmp = a[m];
                a[m] = a[q];
                a[q] = tmp;
                m = m + 1;
                q = n - 1;
                while (m < q)
                {
                    tmp = a[m];
                    a[m] = a[q];
                    a[q] = tmp;
                    q--;
                    m++;
                }
                PrintSeq(a);
            }
        } 
        #endregion
        //algorithm of Combination
        #region 排列运算
        public static void C(int n, int r)
        {
            int[] a = new int[r];
            for (int i = 0; i < r; i++)
                a[i] = seq[i];
            PrintSeq(a);
            for (int k = 1; k < CountC(n, r); k++)
            {
                int max_val = seq[n - 1];
                int m = r - 1;
                while (a[m] == max_val)
                {
                    m -= 1;
                    max_val -= 1;
                }
                a[m] += 1;
                for (int j = m + 1; j < r; j++)
                    a[j] = a[j - 1] + 1;
                PrintSeq(a);
            }
        } 
        #endregion

    }
}
